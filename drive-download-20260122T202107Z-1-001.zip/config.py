import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    PROJECT_ID = os.getenv("PROJECT_ID")
    LOCATION = os.getenv("LOCATION", "global")
    COLLECTION_ID = os.getenv("COLLECTION_ID", "default_collection")
    ENGINE_ID = os.getenv("ENGINE_ID")
    SERVING_CONFIG_ID = os.getenv("SERVING_CONFIG_ID", "default_search")
    REASONING_ENGINE_ID = os.getenv("REASONING_ENGINE_ID")
    REASONING_ENGINE_LOCATION = os.getenv("REASONING_ENGINE_LOCATION", "us-central1")
