#!/bin/bash
set -e

# Configuration
PROJECT_ID="your-project-id-here"
REGION="us-central1"
MIDDLEWARE_NAME="adp-middleware"
ENGINE_ID="your-engine-id-here"

echo "Deploying Middleware..."
gcloud run deploy $MIDDLEWARE_NAME \
  --source . \
  --region $REGION \
  --allow-unauthenticated \
  --set-env-vars PROJECT_ID="$PROJECT_ID",LOCATION="global",COLLECTION_ID="default_collection",ENGINE_ID="$ENGINE_ID",SERVING_CONFIG_ID="default_search"

# Get the Middleware URL
MIDDLEWARE_URL=$(gcloud run services describe $MIDDLEWARE_NAME --region $REGION --format 'value(status.url)')
echo "Middleware Deployed at: $MIDDLEWARE_URL"