import json
import uuid
import requests
import google.auth
from google.auth.transport.requests import Request as AuthRequest
from flask import Flask, request, jsonify
from config import Config

app = Flask(__name__)

class AuthService:
    @staticmethod
    def get_access_token() -> str | None:
        try:
            credentials, _ = google.auth.default()
            credentials.refresh(AuthRequest())
            return credentials.token
        except Exception as e:
            print(f"Error getting access token: {e}")
            return None

@app.route('/answer', methods=['POST'])
def get_answer():
    data = request.json
    query_text = data.get('query')
    session_name = data.get('session')  # Optional session resource name

    if not query_text:
        return jsonify({"error": "Query is required"}), 400

    access_token = AuthService.get_access_token()
    if not access_token:
        return jsonify({"error": "Failed to authenticate"}), 500

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    project_id = Config.PROJECT_ID
    location = Config.LOCATION
    collection_id = Config.COLLECTION_ID
    engine_id = Config.ENGINE_ID
    serving_config_id = Config.SERVING_CONFIG_ID
    
    # Construct session if not provided, or use "-" for new session if preferred logic
    # But VAIS usually takes a session name like projects/.../sessions/SESSION_ID
    # If client sends just a session ID, we might need to format it, but let's assume client sends full name or nothing.
    # Actually, for "Ask a follow-up", we usually need the session name returned from previous turn.
    
    # If no session provided, let's use "-" to let API create one, but strictly speaking 
    # for 'answer' method, 'session' field in body is a resource name.
    
    api_url = f"https://discoveryengine.googleapis.com/v1alpha/projects/{project_id}/locations/{location}/collections/{collection_id}/engines/{engine_id}/servingConfigs/{serving_config_id}:answer"
    
    payload = {
        "query": {"text": query_text},
        "session": session_name, # Can be None/null, API handles it (starts new session usually)
        # Add simpler spec as requested
        "relatedQuestionsSpec": {"enable": True},
        "answerGenerationSpec": {
            "includeCitations": True,
            "answerLanguageCode": "en",
        }
    }

    if not session_name:
        try:
            # Explicitly create a session
            session_api_url = f"https://discoveryengine.googleapis.com/v1alpha/projects/{project_id}/locations/{location}/collections/{collection_id}/engines/{engine_id}/sessions"
            session_payload = {"userPseudoId": "test-user"} # Optional but good practice
            session_resp = requests.post(session_api_url, headers=headers, json=session_payload)
            if session_resp.status_code == 200:
                session_name = session_resp.json().get("name")
            else:
                print(f"Failed to create session: {session_resp.text}")
        except Exception as e:
            print(f"Session creation exception: {e}")

    if session_name:
        payload["session"] = session_name
    
    # If session is None, we might want to omit it or send spec to create new.
    # The Answer API documentation says 'session' is "The resource name of the session."
    # If missing, a new session is created.


    try:
        response = requests.post(api_url, headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()
        
        # Simplified response
        answer_data = result.get("answer", {})
        
        session_val = result.get("session")
        session_name_out = None
        if isinstance(session_val, dict):
             session_name_out = session_val.get("name")
        else:
             session_name_out = session_val
             
        # Fallback to sessionInfo if session was None (though unlikely now)
        if not session_name_out:
             session_info = result.get("sessionInfo", {})
             session_name_out = session_info.get("name")
        
        output = {
            "answer": answer_data.get("answerText", "No answer found."),
            "citations": answer_data.get("citations", []),
            "session": session_name_out,
            "related_questions": answer_data.get("relatedQuestions", [])
        }
        
        return jsonify(output)


    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if e.response is not None:
             error_msg = e.response.text
        return jsonify({"error": f"API request failed: {error_msg}"}), 500

@app.route('/reasoning/answer', methods=['POST'])
def get_reasoning_answer():
    data = request.json
    query_text = data.get('query')
    # Match /answer route behavior:
    # Get session from request, or create new one if not provided.
    session_id = data.get('session')
    
    if not query_text:
        return jsonify({"error": "Query is required"}), 400

    access_token = AuthService.get_access_token()
    if not access_token:
        return jsonify({"error": "Failed to authenticate"}), 500

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Generate new session ID if not provided
    if not session_id:
        # The deployed Reasoning Engine agent appears to rely on user_id for context 
        # and returns empty responses when provided with random UUID session IDs.
        # We default to empty string to ensure the agent works as expected.
        session_id = "" 

    # Build URL from Config
    # Using :streamQuery?alt=sse for streaming response
    re_project_id = Config.PROJECT_ID # Reuse project ID as requested or from config
    re_location = Config.REASONING_ENGINE_LOCATION
    re_id = Config.REASONING_ENGINE_ID
    
    api_url = f"https://{re_location}-aiplatform.googleapis.com/v1/projects/{re_project_id}/locations/{re_location}/reasoningEngines/{re_id}:streamQuery?alt=sse"
    
    # Payload for Reasoning Engine with async_stream_query
    payload = {
        "class_method": "async_stream_query",
        "input": {
            "message": query_text,
            "session_id": session_id,
            "user_id": "test" # Keeping hardcoded for now or could generate per user if needed
        }
    }

    try:
        response = requests.post(api_url, headers=headers, json=payload, stream=True)
        response.raise_for_status()
        print(f"DEBUG Headers: {response.headers}", flush=True)
        
        # Consuming SSE stream
        accumulated_text = []
        
        for line in response.iter_lines():
            if line:
                decoded_line = line.decode('utf-8').strip()
                if not decoded_line:
                    continue
                
                print(f"DEBUG STREAM: {decoded_line}", flush=True)
                
                json_str = decoded_line
                if decoded_line.startswith('data: '):
                    json_str = decoded_line[6:] # Strip "data: "
                
                try:
                    data = json.loads(json_str)
                    
                    content = data.get('content', {})
                    parts = content.get('parts', [])
                    for part in parts:
                        if 'text' in part:
                            accumulated_text.append(part['text'])
                except json.JSONDecodeError:
                    print(f"Failed to decode JSON: {json_str}", flush=True)
                    pass

        full_answer = "".join(accumulated_text)
        if not full_answer:
            full_answer = "No text returned from stream."
            
        # Match response format of /answer route
        return jsonify({
            "answer": full_answer,
            "citations": [], # Not currently returned by RE
            "session": session_id, # Return the session ID used/created
            "related_questions": [] # Not currently returned by RE
        })

    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if e.response is not None:
             error_msg = e.response.text
        return jsonify({"error": f"Reasoning Engine Request failed: {error_msg}"}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8081)
